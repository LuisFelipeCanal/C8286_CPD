﻿\# Desarrollo Actividad 0

`$ docker container run rancher/cowsay Hello`![](Aspose.Words.0ae08e00-c848-433e-8209-b950c0e8bfea.001.png)![](Aspose.Words.0ae08e00-c848-433e-8209-b950c0e8bfea.002.png)![](Aspose.Words.0ae08e00-c848-433e-8209-b950c0e8bfea.003.png)
